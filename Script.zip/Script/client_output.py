from socket import *
from mraa import *
from time import *

HOST = '10.42.0.1'
PORT = 28812
BUFSIZE = 1024
sens1 = Aio(0)
sens2 = Aio(1)
sens3 = Aio(2)
sens4 = Aio(3)
def send():
	tcpTimeClientSock = socket(AF_INET, SOCK_STREAM)
	tcpTimeClientSock.connect((HOST,PORT))
	while True:
		data0 = 'sens1,'+str(float(sens1.read()))
		tcpTimeClientSock.send(data0)
		sleep(1)
                data1 = 'sens2,'+str(float(sens2.read()))
                tcpTimeClientSock.send(data1)
                sleep(1)
		data2 = 'sens3,'+str(float(sens3.read()))
                tcpTimeClientSock.send(data2)
                sleep(1)
		data3 = 'sens4,'+str(float(sens4.read()))
                tcpTimeClientSock.send(data3)
                sleep(1)
	tcpTimeClientSock.close()
send()
