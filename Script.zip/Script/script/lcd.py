while 1:
	import time, mraa, pyupm_i2clcd
	import pyupm_grove as grove
	temp = grove.GroveTemp(3)
	min=25-2
	max=25+2
	lv=mraa.Gpio(4)
	lv.dir(mraa.DIR_OUT)
	lr=mraa.Gpio(3)
	lr.dir(mraa.DIR_OUT)
	lcd = pyupm_i2clcd.Jhd1313m1(0, 0x3E, 0x62)
	lcd.setColor(0,50,50)
	if ((temp.value()>=min)and(temp.value()<=max)):
		lv.write(1)
        	lr.write(0)
        	lcd.clear()
        	lcd.write('Temperatura OK!')
	elif (temp.value()<min):
        	lv.write(0)
        	lr.write(1)
        	lcd.clear()
        	lcd.write('Temperatura bassa: avvio riscaldamento!')
	print(temp.value())
	time.sleep(1)
	p = mraa.Aio(0)
	relay1 = grove.GroveRelay(7)
	relay2 = grove.GroveRelay(6)
	potVal = float(p.read())/10
	print(potVal)
	if ((potVal>=33)and(potVal<66)):
        	lcd.setColor(255,215,0)
		lcd.clear()
       		lcd.write('relay1 e\' stato escluso per insufficienza di energia.')
        	relay1.on()
        	relay2.off()
	elif((potVal>=66)and(potVal<=100)):
        	lcd.setColor(255,0,0)
		lcd.clear()
        	lcd.write('realy1 e relay2 sono stati esclusi per insufficienza di energia.')
        	relay1.on()
        	relay2.on()
	else:	
		lcd.setColor(0,50,50)
		lcd.clear()
		lcd.write('Tutti i sistemi sono attivi')
     		relay1.off()
        	relay2.off()
	time.sleep(3)
