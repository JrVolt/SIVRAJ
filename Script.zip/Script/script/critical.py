import time
import pyupm_grove as grove
import time import pyupm_i2clcd


lcd = pyupm_i2clcd.Jhd1313m1(0, 0x3E, 0x62)
lcd.setColor(0,50,50)
lcd.write('Controllo energia inizializzato!')
time.sleep(3)
p=mraa.Aio(0)
relay1 = grove.GroveRelay(7)
relay2 = grove.GroveRelay(6)
in=(p.read())/10
if ((in>=33)and(in<66)):
        lcd.setColor(255,215,0)
	lcd.clear()
        lcd.write(relay1.name(),' e' stato escluso per insufficienza di energia.')
        relay1.on()
        relay2.off()
elif((in>=66)and(in<=100)):
        lcd.setColor(255,0,0)
	lcd.clear()
        lcd.write(relay1.name(),'e',relay2.name()' sono stati esclusi per insufficienza di 
energia.'
        relay1.on()
        relay2.on()
else:	
	lcd.setColor(0,50,50)
	lcd.clear()
	lcd.write('Tutti i sistemi sono attivi')
     	relay1.off()
        relay2.off()

