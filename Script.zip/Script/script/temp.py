import time, mraa

a0=mraa.Aio(3)
while 1:
	print(a0.read())
	
