import time, mraa, pyupm_i2clcd
import pyupm_grove as grove
temp = grove.GroveTemp(3)
t=40
min=t-2
max=t+2
lv=mraa.Gpio(4)
lv.dir(mraa.DIR_OUT)
lr=mraa.Gpio(3)
lr.dir(mraa.DIR_OUT)
lcd = pyupm_i2clcd.Jhd1313m1(0, 0x3E, 0x62)
lcd.setColor(0,50,50)
while 1:
       	if ((temp.value()>=min)and(temp.value()<=max)):
             	lv.write(1)
           	lr.write(0)
              	lcd.clear()
		lcd.write('Temperatura OK!')
      	elif (temp.value()<min):
          	lv.write(0)
            	lr.write(1)
            	lcd.clear()
                lcd.write('Temperatura bassa: avvio riscaldamento!')
	print(temp.value())
