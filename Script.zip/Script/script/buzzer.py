import mraa
import time

buzzer = mraa.Gpio(4)
buzzer.dir(mraa.DIR_OUT)

buzzer.write(1)
time.sleep(0.2)
buzzer.write(0)
time.sleep(0.2)
