from socket import *
from mraa import *
from time import *

HOST = '10.42.0.1'
PORT = 28812
BUFSIZE = 1024
tcpTimeClientSock = socket(AF_INET, SOCK_STREAM)
tcpTimeClientSock.connect((HOST,PORT))

def listen():
	while True:
		data = tcpTimeClientSock.recv(BUFSIZE)
		sens = Gpio(int(data))
		data = str(sens.read())
		tcpTimeClientSock.sent(data)

listen()
tcpTimeClientSock.close()
