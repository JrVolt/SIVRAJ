from socket import *
from mraa import *
from time import *

HOST = '10.42.0.1'
PORT = 28813
BUFSIZE = 1024
def listen():
	tcpTimeClientSock = socket(AF_INET, SOCK_STREAM)
	tcpTimeClientSock.connect((HOST,PORT))
	while True:
		data = tcpTimeClientSock.recv(BUFSIZE)
		if data == 'exit':
			break;
		gpio, state = data.split(',')
		pot = Gpio(int(gpio))
		pot.dir(DIR_OUT)
		if state == 'ON':
			pot.write(1)
		if state == 'OFF':
			pot.write(0)
	tcpTimeClientSock.close()

listen()
